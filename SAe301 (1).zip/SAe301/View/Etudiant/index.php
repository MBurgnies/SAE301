<?php
session_start();

require "../../Model/CSV.php";
require "../../Model/BDD.php";
require "../../Model/function.php";



$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    web_conn($_POST['idt'], $_POST['password'],$error);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Gestion Absences</title>
    <link rel="stylesheet" href="/View/Etudiant/index.css"/>
</head>
<body>
<div class="header">
    <img src="../../logo.png" alt="Logo UPHF">
    <h2 style="margin-left:20px;">ESPACE NUMÉRIQUE DE TRAVAIL</h2>
</div>

<div class="container">
    <div class="form-box">
        <h2>Connexion</h2>
        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form method="POST">
            <label>Nom d’utilisateur
            <input type="text" name="idt" placeholder="Entrez votre nom..." value="<?= htmlspecialchars($email ?? '') ?>" required>
            </label>
            <label>Mot de passe
            <input type="password" name="password" placeholder="Entrez votre mot de passe..." required>
            </label>
            <button type="submit">Envoyer</button>
        </form>
    </div>
</div>

<div class="footer"></div>
</body>
</html>