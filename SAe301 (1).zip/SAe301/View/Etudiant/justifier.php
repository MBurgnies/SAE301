<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

$date = $_POST['date'] ?? null;
if (!$date) {
    header('Location: dashboard.php');
    exit;
}

$confirmation = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['motif'])) {
    $email = trim($_POST['email']);
    $motif = trim($_POST['motif']);
    $commentaire = trim($_POST['commentaire']);

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Veuillez renseigner une adresse email valide.";
    } elseif (empty($motif)) {
        $error = "Veuillez sélectionner un motif.";
    } else {

        $subject = "[Gestion-Absence] Justificatif soumis";
        $message = "Bonjour,\n\nVotre justificatif pour l'absence du $date a bien été soumis.\n\nMotif : $motif\nCommentaire : $commentaire\n\nCordialement,\nService Gestion Absences";
        $headers = "From: no-reply@uphf.fr\r\n";
        @mail($email, $subject, $message, $headers);

        $confirmation = "Justificatif soumis pour l'absence du $date. Un mail de confirmation a été envoyé à $email.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Justification</title>
    <link rel="stylesheet" href="/View/Etudiant/justifier.css"/>
</head>
<body>
<div class="container">
    <h2>Justification pour l'absence du <?= htmlspecialchars($date) ?></h2>

    <?php if ($confirmation): ?>
        <p class="confirmation"><?= htmlspecialchars($confirmation) ?></p>
        <a href="dashboard.php">Retour au tableau de bord</a>
    <?php else: ?>
        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="hidden" name="date" value="<?= htmlspecialchars($date) ?>">

            <label>Adresse email :</label>
            <input type="email" name="email" value="<?= htmlspecialchars($_SESSION['user']['email']) ?>" required>

            <label>Motif :</label>
            <select name="motif" required>
                <option value="">--Sélectionnez--</option>
                <option value="Maladie">Maladie</option>
                <option value="Décès">Décès</option>
                <option value="Obligations familiales">Obligations familiales</option>
                <option value="Autre">Autre</option>
            </select>

            <label>Commentaire :</label>
            <textarea name="commentaire" rows="4"></textarea>

            <button type="submit">Soumettre le justificatif</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>