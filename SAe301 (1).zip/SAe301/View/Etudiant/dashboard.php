<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user']['identifiant'])) {
    header('Location: View/Etudiant/index.php');
    exit;
}

require_once "../../Model/function.php"; // contient get_absences()
require_once "../../Model/BDD.php";      // contient conn_bdd()

$user_identifiant = $_SESSION['user']['identifiant'];

try {
    $pdo = conn_bdd();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // On récupère les absences via la fonction
    $resultats = get_absences($pdo, $user_identifiant);

    $absences_a_justifier = $resultats["absences_a_justifier"];
    $historique = $resultats["historique"];

} catch (PDOException $e) {
    die("Erreur PDO : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des absences</title>
    <link rel="stylesheet" href="/View/Etudiant/dashboard.css">
</head>
<body>
<header>
    <div style="display:flex;align-items:center;">
        <img src="../../logo.png" alt="Logo UPHF">
        <h2 style="margin-left:15px;">Gestion des absences</h2>
    </div>
    <a href="logout.php" class="logout">Déconnexion</a>
</header>

<div class="container">
    <div>
        <h2>Absences à justifier</h2>
        <table>
            <tr>
                <th>Prénom</th>
                <th>Nom</th>
                <th>Diplôme</th>
                <th>Date</th>
                <th>Évaluation</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($absences_a_justifier)): ?>
                <?php foreach ($absences_a_justifier as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a["prenom"]) ?></td>
                        <td><?= htmlspecialchars($a["nom"]) ?></td>
                        <td><?= htmlspecialchars($a["diplome"]) ?></td>
                        <td><?= htmlspecialchars($a["date"]) ?></td>
                        <td><?= htmlspecialchars($a["eval"]) ?></td>
                        <td>
                            <?php if (!($a['locked'])): ?>
                                <form method="POST" action="justifier.php">
                                    <input type="hidden" name="date" value="<?= htmlspecialchars($a['date']) ?>">
                                    <button type="submit" class="btn blue"><?= htmlspecialchars($a["action"]) ?></button>
                                </form>
                            <?php else: ?>
                                <span class="red">Justification fermée</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">Aucune absence à justifier</td></tr>
            <?php endif; ?>
        </table>
    </div>

    <div>
        <h2>Historique des absences</h2>
        <table>
            <tr>
                <th>Prénom</th>
                <th>Nom</th>
                <th>Diplôme</th>
                <th>Date</th>
                <th>Statut</th>
                <th>Évaluation</th>
                <th>Motif</th>
            </tr>
            <?php if (!empty($historique)): ?>
                <?php foreach ($historique as $h): ?>
                    <tr>
                        <td><?= htmlspecialchars($h["prenom"]) ?></td>
                        <td><?= htmlspecialchars($h["nom"]) ?></td>
                        <td><?= htmlspecialchars($h["diplome"]) ?></td>
                        <td><?= htmlspecialchars($h["date"]) ?></td>
                        <td class="<?php
                        if ($h["statut"] === 'Accepter') echo 'green';
                        elseif ($h["statut"] === 'Refuser') echo 'red';
                        else echo 'blue';
                        ?>"><?= htmlspecialchars($h["statut"]) ?></td>
                        <td><?= htmlspecialchars($h["eval"]) ?></td>
                        <td>
                            <?php if (!empty($h["motif"])): ?>
                                <button class="btn grey" onclick="alert('Motif: <?= htmlspecialchars($h['motif']) ?>')">Voir le motif</button>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="7">Aucun historique</td></tr>
            <?php endif; ?>
        </table>
    </div>
</div>

</body>
</html>
