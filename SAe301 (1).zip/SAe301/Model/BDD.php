<?php
function conn_bdd()
{
    $host_name = 'db5018670203.hosting-data.io';
    $database  = 'dbs14788540';
    $user_name = 'dbu4927107';
    $password  = 'SAE301bdd';

    try {
        $pdo = new PDO(
            "mysql:host=$host_name;dbname=$database;charset=utf8;port=3306",
            $user_name,
            $password
        );

        // Définir le mode d'erreur sur Exception
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $pdo; // retourne l'objet PDO
    } catch (PDOException $e) {
        die('<p>La connexion au serveur MySQL a échoué : ' . $e->getMessage() . '</p>');
    }
}
