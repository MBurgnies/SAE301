<?php

function import_csv($pdo) {
    $fichier = fopen("Model/VT/import1.CSV", "r");

    if (!$fichier) {
        die("❌ Impossible d’ouvrir le fichier CSV");
    }

    $headers = fgetcsv($fichier, 1000, ";");

    $clean_headers = [];
    foreach ($headers as $col) {
        $col = preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower($col));
        $clean_headers[] = $col;
    }

    $tableExists = $pdo->query("SHOW TABLES LIKE 'export_vt'")->rowCount() > 0;

    if (!$tableExists) {
        $cols = [];
        foreach ($clean_headers as $col) {
            $cols[] = "`$col` TEXT"; // par défaut TEXT
        }
        $sql = "CREATE TABLE export_vt (
            id INT AUTO_INCREMENT PRIMARY KEY,
            " . implode(", ", $cols) . "
        )";
        $pdo->exec($sql);
    }

    $placeholders = implode(",", array_fill(0, count($clean_headers), "?"));
    $insertSql = "INSERT INTO export_vt (`" . implode("`,`", $clean_headers) . "`) VALUES ($placeholders)";
    $insertStmt = $pdo->prepare($insertSql);

    $checkSql = "SELECT COUNT(*) FROM export_vt WHERE " .
        implode(" AND ", array_map(function ($c) {
            return "`$c` = ?";
        }, $clean_headers));
    $checkStmt = $pdo->prepare($checkSql);

    $nbInserted = 0;
    $nbSkipped = 0;

    while (($ligne = fgetcsv($fichier, 1000, ";")) !== FALSE) {
        $checkStmt->execute($ligne);
        $exists = $checkStmt->fetchColumn() > 0;

        if (!$exists) {
            $insertStmt->execute($ligne);
            $nbInserted++;
        } else {
            $nbSkipped++;
        }
    }

    fclose($fichier);

}
