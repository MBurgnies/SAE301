<?php
function web_conn($idt, $password, &$error) { // & pour passer par référence
    $pdo = conn_bdd();
    $idt = explode('.', $idt, 2);

    if (count($idt) < 2) {
        $error = "Format de l'identifiant incorrect (ex: prenom.nom)";
        return false;
    }

    $prenom = $idt[0];
    $nom    = $idt[1];

    $sql = "SELECT role FROM user WHERE first_name = :prenom AND last_name = :nom AND password = :password LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':prenom', $prenom, PDO::PARAM_STR);
    $stmt->bindParam(':nom', $nom, PDO::PARAM_STR);
    $stmt->bindParam(':password', $password, PDO::PARAM_STR);

    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $role = strtolower(trim($user['role'] ?? ''));

    if (findUser($pdo, $prenom, $nom, $password)) {
        $_SESSION['user'] = [
            "identifiant" => $idt[0] . '.' . $idt[1],
            "prenom" => $prenom,
            "nom" => $nom
        ];
        if ($role === "rp") {
            header('Location: /View/RP/dashboard.php');
            exit;
        } elseif ( $role === "student") {
//            header('Location: dashboard.php');
            header('Location: /View/Etudiant/dashboard.php');
            exit;
        }

        exit;
    } else {
        $error = "Identifiant ou mot de passe incorrect.";
        return $error;
    }
}



function findUser($pdo, $first_name, $last_name, $password)
{
    $sql = "SELECT * FROM user WHERE first_name = :first_name AND last_name = :last_name AND password = :password LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':first_name', $first_name, PDO::PARAM_STR);
    $stmt->bindParam(':last_name', $last_name, PDO::PARAM_STR);
    $stmt->bindParam(':password', $password, PDO::PARAM_STR);

    $stmt->execute();

    return $stmt->fetch(PDO::FETCH_ASSOC);
}


function get_absences($pdo, $identifiant){
    $absences_a_justifier = [];
    $historique = [];

    try {
        if (!($identifiant === null)){
            $identifiant = explode('.', $identifiant, 2);
            $first_name=$identifiant[0];
            $last_name=$identifiant[1];

            $sql = ("SELECT * FROM export_vt WHERE pr__nom = :first_name AND ___nom = :last_name ORDER BY date DESC");
            $stmt = $pdo->prepare($sql);

            $stmt->bindParam(':first_name', $first_name, PDO::PARAM_STR);
            $stmt->bindParam(':last_name', $last_name, PDO::PARAM_STR);
        } else {
            $stmt = $pdo->prepare("SELECT * FROM export_vt ORDER BY date DESC");
        }
        $stmt->execute();

        $absences = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($absences as $absence) {
            if (!isset($absence['date'])) continue;

            // Date
            $date_abs = DateTime::createFromFormat('d/m/Y', $absence['date']);
            if (!$date_abs) {
                $date_abs = new DateTime($absence['date']);
            }
            $now = new DateTime();
            $diff = $now->diff($date_abs)->days;

            // Nettoyage données
            $justification = strtolower(trim($absence['justification'] ?? ''));
            $motif_absence = trim($absence['motif_absence'] ?? '');
            $absent_pr_sent = strtolower(trim($absence['absent_pr__sent'] ?? ''));

            // Récupération prénom, nom, diplôme directement depuis export_vt
            $prenom = $absence['pr__nom'] ?? '';
            $nom = $absence['___nom'] ?? '';
            $diplome = isset($absence['dipl__mes']) ? substr(trim($absence['dipl__mes']), 0, 4) : '';

            if ($motif_absence === "?" AND $absence["contr__le"] === "Non") {
                $absences_a_justifier[] = [
                    "prenom" => $prenom,
                    "nom" => $nom,
                    "diplome" => $diplome,
                    "date" => $absence['date'],
                    "eval" => $absent_pr_sent === "oui" ? "oui" : "non",
                    "action" => "À justifier",
                    "locked" => $diff > 2
                ];
            } else {
                if ($absence['justification'] === "Absence justifiée") {
                    $historique[] = [
                        "prenom" => $prenom,
                        "nom" => $nom,
                        "diplome" => $diplome,
                        "date" => $absence['date'],
                        "statut" => "Accepter",
                        "eval" => $absent_pr_sent === "oui" ? "oui" : "non",
                        "motif" => $motif_absence
                    ];
                } else {
                    $historique[] = [
                        "prenom" => $prenom,
                        "nom" => $nom,
                        "diplome" => $diplome,
                        "date" => $absence['date'],
                        "statut" => "Refuser",
                        "eval" => $absent_pr_sent === "oui" ? "oui" : "non",
                        "motif" => $motif_absence
                    ];
                }
            }
        }

    } catch (PDOException $e) {
        die("Erreur PDO : " . $e->getMessage());
    }

    return [
        "absences_a_justifier" => $absences_a_justifier,
        "historique" => $historique
    ];
}
